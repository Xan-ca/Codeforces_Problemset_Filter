/**
 * content.js — Codeforces Problemset Filter (robust version)
 *
 * Uses multiple fallback selectors for both the sidebar and the problem table,
 * and falls back to a floating widget if no sidebar is found.
 */

(function () {
  'use strict';

  const STORAGE_KEY_FILTER = 'cf_selected_category';
  const SIDEBOX_ID = 'cf-filter-sidebox';
  const extAPI = typeof browser !== 'undefined' ? browser : chrome;

  const CATEGORIES = [
    { value: 'all', label: 'All Problems' },
    { value: 'Div. 1', label: 'Div. 1' },
    { value: 'Div. 2', label: 'Div. 2' },
    { value: 'Div. 3', label: 'Div. 3' },
    { value: 'Div. 4', label: 'Div. 4' },
    { value: 'Educational', label: 'Educational' },
    { value: 'Global', label: 'Global Round' },
    { value: 'ICPC', label: 'ICPC' },
  ];

  function queryAny(...selectors) {
    for (const sel of selectors) {
      try {
        const el = document.querySelector(sel);
        if (el) { console.log('[CF Filter] Matched selector: "' + sel + '"'); return el; }
      } catch (e) { }
    }
    return null;
  }

  function getProblemId(row) {
    const cell = row.querySelector('td:first-child');
    if (!cell) return '';
    return cell.innerText.replace(/\s+/g, '').trim();
  }

  async function getSavedFilter() {
    return new Promise((resolve) => {
      extAPI.storage.local.get(STORAGE_KEY_FILTER, (r) => {
        let val = r[STORAGE_KEY_FILTER];
        if (val === undefined || val === null || val === 'all') {
          resolve([]);
        } else if (typeof val === 'string') {
          resolve([val]); // handles legacy storage where a single string was saved
        } else if (Array.isArray(val)) {
          resolve(val);
        } else {
          resolve([]);
        }
      });
    });
  }

  function saveFilter(values) {
    extAPI.storage.local.set({ [STORAGE_KEY_FILTER]: values });
  }

  function buildSidebox() {
    if (!document.getElementById('cf-filter-styles')) {
      const style = document.createElement('style');
      style.id = 'cf-filter-styles';
      style.textContent = `
        .cf-filter-opts { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
        .cf-filter-lbl { cursor: pointer; user-select: none; }
        .cf-filter-cb { display: none; }
        .cf-filter-txt {
          display: inline-block;
          padding: 4px 8px;
          border: 1px solid #b9b9b9;
          border-radius: 4px;
          background: #f8f8f8;
          color: #222;
          font-size: 11px;
          font-family: inherit;
          transition: all 0.1s ease-in-out;
        }
        .cf-filter-lbl:hover .cf-filter-txt {
          background: #e8e8e8;
        }
        .cf-filter-cb:checked + .cf-filter-txt {
          background: #e1eefc;
          border-color: #3b5998;
          color: #3b5998;
          font-weight: bold;
        }
        #cf-filter-clear {
          width: 100%;
          padding: 5px;
          font-size: 12px;
          cursor: pointer;
          border: 1px solid #b9b9b9;
          background: #eee;
          border-radius: 4px;
          color: #333;
          transition: background 0.1s;
        }
        #cf-filter-clear:hover { background: #ddd; }
      `;
      document.head.appendChild(style);
    }

    const sidebox = document.createElement('div');
    sidebox.id = SIDEBOX_ID;
    sidebox.className = 'sidebox';

    const opts = CATEGORIES.filter(c => c.value !== 'all').map(c =>
      '<label class="cf-filter-lbl">' +
      '<input type="checkbox" value="' + c.value + '" class="cf-filter-cb">' +
      '<span class="cf-filter-txt">' + c.label + '</span>' +
      '</label>'
    ).join('');

    sidebox.innerHTML =
      '<div class="roundbox">' +
      '<div class="caption titled" style="font-weight:bold;padding:6px 8px;border-bottom:1px solid #b9b9b9;">' +
      '&#9776; Filter Categories' +
      '</div>' +
      '<div class="content" style="padding:10px;">' +
      '<div class="cf-filter-opts">' +
      opts +
      '</div>' +
      '<div>' +
      '<button id="cf-filter-clear">Clear Filters (Show All)</button>' +
      '</div>' +
      '</div>' +
      '</div>';

    return sidebox;
  }

  function injectSidebox() {
    if (document.getElementById(SIDEBOX_ID)) {
      return document.getElementById(SIDEBOX_ID);
    }

    console.log('[CF Filter] body class: ' + document.body.className);

    const sidebar = queryAny(
      '._rightVertical',
      '.right-sidebar',
      '#sidebar',
      '.sidebar',
      '[class*="rightVertical"]',
      '[class*="right"]',
      'td.right-sidebar',
      '.roundbox-list',
    );

    const sidebox = buildSidebox();

    if (sidebar) {
      console.log('[CF Filter] Sidebar found: ' + sidebar.tagName + ' / ' + sidebar.className);
      const firstChild = sidebar.firstElementChild;
      if (firstChild) sidebar.insertBefore(sidebox, firstChild);
      else sidebar.appendChild(sidebox);
    } else {
      console.warn('[CF Filter] No sidebar found — using floating widget');
      sidebox.style.cssText = 'position:fixed;top:80px;right:12px;z-index:99999;width:185px;box-shadow:0 2px 10px rgba(0,0,0,0.2);border-radius:4px;background:#fff;border:1px solid #ddd;';
      document.body.appendChild(sidebox);
    }

    return sidebox;
  }

  function findProblemsTable() {
    return queryAny(
      'table.problems',
      '.problemset table',
      '#pageContent table',
      'table[class*="problem"]',
      'main table',
      'table'
    );
  }

  function applyFilter(selectedCategories, problemMap) {
    const table = findProblemsTable();
    if (!table) { console.warn('[CF Filter] No table found'); return { shown: 0, hidden: 0 }; }

    const rows = table.querySelectorAll('tr');
    console.log('[CF Filter] Filtering ' + rows.length + ' rows, categories=' + selectedCategories.join(','));

    let shown = 0, hidden = 0;

    for (const row of rows) {
      if (!row.querySelector('td')) continue;
      const id = getProblemId(row);
      if (!id) continue;

      if (!selectedCategories || selectedCategories.length === 0) { row.style.display = ''; shown++; continue; }

      const problem = problemMap[id];
      if (!problem) { row.style.display = ''; shown++; continue; }

      const matches = Array.isArray(problem.categories) && selectedCategories.some(c => problem.categories.includes(c));
      if (matches) { row.style.display = ''; shown++; }
      else { row.style.display = 'none'; hidden++; }
    }

    console.log('[CF Filter] shown=' + shown + ' hidden=' + hidden);
    return { shown, hidden };
  }

  async function init() {
    console.log('[CF Filter] init() on ' + location.href);

    const path = window.location.pathname;
    // Only run on the main problemset page, or its paginated paths.
    if (!/^(\/problemset\/?|\/problemset\/page\/\d+\/?)$/.test(path)) {
      console.log('[CF Filter] Not a problemset listing page. Aborting extension initialization.');
      return;
    }

    if (!findProblemsTable()) {
      console.log('[CF Filter] No problems table found. Aborting.');
      return;
    }

    const sidebox = injectSidebox();
    if (!sidebox) { console.error('[CF Filter] No sidebox injected'); return; }

    let problemMap = null;
    try {
      const response = await extAPI.runtime.sendMessage({ type: 'GET_PROBLEM_MAP' });
      if (response && response.success) {
        problemMap = response.problemMap;
      } else {
        console.error('[CF Filter] Error from background:', response);
        return;
      }
    } catch (err) {
      console.error('[CF Filter] sendMessage error:', err);
      return;
    }

    let savedCategories = await getSavedFilter();

    const checkboxes = document.querySelectorAll('.cf-filter-cb');
    const updateCheckboxes = () => {
      checkboxes.forEach(cb => {
        cb.checked = savedCategories.includes(cb.value);
      });
    };
    updateCheckboxes();

    const applyAndSave = () => {
      saveFilter(savedCategories);
      applyFilter(savedCategories, problemMap);
    };

    applyAndSave();

    checkboxes.forEach(cb => {
      cb.addEventListener('change', () => {
        if (cb.checked) {
          if (!savedCategories.includes(cb.value)) savedCategories.push(cb.value);
        } else {
          savedCategories = savedCategories.filter(v => v !== cb.value);
        }
        applyAndSave();
      });
    });

    document.getElementById('cf-filter-clear').addEventListener('click', () => {
      savedCategories = [];
      updateCheckboxes();
      applyAndSave();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
