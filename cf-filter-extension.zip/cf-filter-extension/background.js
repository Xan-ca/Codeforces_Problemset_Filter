/**
 * background.js — Service Worker (Manifest V3)
 *
 * Responsibilities:
 *   1. Fetch enriched_problems.json from the GitHub Pages API.
 *   2. Cache the result in chrome.storage.local with a 24-hour TTL.
 *   3. Respond to messages from content.js requesting the problem map.
 */

const extAPI = typeof browser !== 'undefined' ? browser : chrome;

const API_URL = 'https://xan-ca.github.io/cf-api/enriched_problems.json';
const CACHE_KEY = 'cf_problems_cache';
const CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

/**
 * Fetches the API, builds a plain-object map keyed by "${contestId}${index}",
 * and persists it with a timestamp in chrome.storage.local.
 *
 * @returns {Promise<Object>} The problem map.
 */
async function fetchAndCache() {
  console.log('[CF Filter] Fetching fresh data from API…');

  const response = await fetch(API_URL);
  if (!response.ok) {
    throw new Error(`API fetch failed: ${response.status} ${response.statusText}`);
  }

  const json = await response.json();
  const problems = json.result ?? json; // support both {result:[]} and bare array

  // Build O(1) lookup map: "1900A" → problem object
  const problemMap = {};
  for (const p of problems) {
    const key = `${p.contestId}${p.index}`;
    problemMap[key] = p;
  }

  const payload = {
    timestamp: Date.now(),
    problemMap,
  };

  await extAPI.storage.local.set({ [CACHE_KEY]: payload });
  console.log(`[CF Filter] Cached ${Object.keys(problemMap).length} problems.`);

  return problemMap;
}

/**
 * Returns the cached problem map if it is still fresh, or fetches a new one.
 *
 * @returns {Promise<Object>}
 */
async function getProblemMap() {
  const stored = await extAPI.storage.local.get(CACHE_KEY);
  const cached = stored[CACHE_KEY];

  if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
    console.log('[CF Filter] Serving from cache.');
    return cached.problemMap;
  }

  return fetchAndCache();
}

// ─── Message listener ────────────────────────────────────────────────────────

extAPI.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'GET_PROBLEM_MAP') {
    getProblemMap()
      .then((problemMap) => sendResponse({ success: true, problemMap }))
      .catch((err) => {
        console.error('[CF Filter] Error fetching problem map:', err);
        sendResponse({ success: false, error: err.message });
      });

    // Return true to keep the message channel open for async sendResponse.
    return true;
  }
});

// Pre-warm the cache when the extension is installed / updated.
extAPI.runtime.onInstalled.addListener(() => {
  getProblemMap().catch((err) =>
    console.warn('[CF Filter] Pre-warm failed:', err)
  );
});
