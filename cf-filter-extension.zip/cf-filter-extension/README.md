# Codeforces Problemset Filter — Chrome Extension

A Manifest V3 Chrome extension that adds a **Filter by Category** dropdown to the [Codeforces Problemset](https://codeforces.com/problemset) page, letting you instantly show only Div. 1, Div. 2, Educational, Global, ICPC, etc. problems.

---

## Installation (Developer Mode)

1. Open Chrome and go to `chrome://extensions/`.
2. Enable **Developer mode** (toggle in the top-right corner).
3. Click **Load unpacked**.
4. Select this folder (`cf-filter-extension/`).

---

## How It Works

### Data Source
- **API**: `https://xan-ca.github.io/cf-api/enriched_problems.json`
- Each problem object contains `contestId`, `index`, `name`, `rating`, `categories[]`, and `solvedCount`.

### Caching (background.js)
- On first load (or after 24 hours), `background.js` fetches the full JSON (~2 MB) and stores it in `chrome.storage.local` with a timestamp.
- Subsequent page visits are served instantly from the cache.
- The cache is pre-warmed on extension install/update.

### Filtering (content.js)
- On every Codeforces problemset page load, `content.js`:
  1. Requests the problem map from the background worker.
  2. Builds a fast O(1) lookup: `"1900A"` → problem object.
  3. Injects a native-styled **sidebox** into `._rightVertical`.
  4. Restores the last-selected filter from `chrome.storage.local`.
  5. Applies the filter by setting `row.style.display = 'none'` on non-matching rows.

### Filter Categories
| Option | Matches `categories` containing… |
|---|---|
| All Problems | *(no filtering)* |
| Div. 1 | `"Div. 1"` |
| Div. 2 | `"Div. 2"` |
| Div. 3 | `"Div. 3"` |
| Div. 4 | `"Div. 4"` |
| Educational | `"Educational"` |
| Global Round | `"Global"` |
| ICPC | `"ICPC"` |

---

## File Structure

```
cf-filter-extension/
├── manifest.json       # Manifest V3 config
├── background.js       # Service worker: fetch, cache, respond to content.js
├── content.js          # DOM injection & filtering logic
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

---

## Permissions Used

| Permission | Reason |
|---|---|
| `storage` | Cache the problem JSON + persist the selected filter |
| `host_permissions: codeforces.com/problemset*` | Run content script on the problemset page |
| `host_permissions: xan-ca.github.io/cf-api/*` | Fetch the enriched problems JSON |

---

## Notes & Troubleshooting

- **Data not loading?** Open DevTools → Background page console and look for `[CF Filter]` log lines. Check that the API URL is reachable.
- **Force-refresh cache**: Go to `chrome://extensions/` → click the extension's **Service Worker** link → in the console run:  
  `chrome.storage.local.remove('cf_problems_cache')`  
  Then reload a problemset page.
- **Problems not found in filter?** Unknown problems are shown (not hidden) to avoid silently hiding valid problems not yet in the dataset.
- The filter selection persists across page navigations and browser restarts via `chrome.storage.local`.
